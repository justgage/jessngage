#include "flyingobject.h"
#include "velocity.h"

void FlyingObject :: advance()
{
}
