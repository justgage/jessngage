// rifle cpp file

#include "rifle.h"
#include "uiDraw.h"

void Rifle::draw()
{
   drawRect(center, width, height, rotation);
}
