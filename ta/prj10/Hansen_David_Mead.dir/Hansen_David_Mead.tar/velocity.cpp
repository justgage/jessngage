//Empty for now... no member functions needed here... I wasn't sure how to do
// the makefile without this empty file.

#include "velocity.h"

