/*************************
 * File: velocity.cpp
 ************************/

#include "velocity.h"
#include <iostream>
using namespace std;

   // velocity methods

