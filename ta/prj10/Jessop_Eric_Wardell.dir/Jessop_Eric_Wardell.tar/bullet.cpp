/*************************
 * File: bullet.cpp
 ************************/
#include "bullet.h"	
#include "point.h"
#include "velocity.h"
#include "uiDraw.h"
#include "flyingobject.h"
