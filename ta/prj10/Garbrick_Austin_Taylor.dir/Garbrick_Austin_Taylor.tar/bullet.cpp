#include "bullet.h"

void Bullet :: draw()
{
   drawDot(p);
}


