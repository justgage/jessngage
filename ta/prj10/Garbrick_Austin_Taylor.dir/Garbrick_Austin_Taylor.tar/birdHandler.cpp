#include "birdHandler.h"

void BirdHandler :: createBirds()
{
   for (int i = 0; i < numBirds; i++)
   {
      birds[i]-> 
   
  
}

void BirdHandler :: updateBirds()
{
   for (int i = 0; i < numBirds; i++)
   {
      birds[i]-> update();
   }
}

void BirdHandler :: hitBirds()
{
   
}

void BirdHandler :: destroyBirds()
{
   
}
